﻿
Building tool is VisualStudio2015.

no mfc.
no atl.
no boost.


// s55.cpp
	D2DWindows program.

// D2Dtest2.cpp
	Windows program entry point.
	int APIENTRY _tWinMain(...

// stdafx.cpp
	list linked lib.

